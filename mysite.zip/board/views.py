from django.shortcuts import get_list_or_404, redirect, render
from django.shortcuts import redirect
from .models import Post
from django.core.files.storage import FileSystemStorage

# Create your views here.
def index(request):
    posts = get_list_or_404(Post.objects.order_by('-id'))
    return render(request, 'board/index.html', {
        "posts":posts,
    })

def new(request):
    # 로그인 하지 않은 사용자는 게시물 작성 못한다.
    if not request.user.in_authenticated:
        return redirect('/login') # 로그인 창으로

    # 요청방식이 POST인 경우 실제 저장 작업을 수행
    if request.method == "POST":
        print(request.POST)
        if 'image' in request.FILES:
            print("upload")
            # 이미지 첨부의 경우
            upload = request.FILES['image']
            # 저장
            fss = FileSystemStorage()
            file = fss.save(upload.name, upload)

            new_post = Post.objects.create(
                title = request.POST['title'],
                content=request.POST['content'],
                image=file,
                author=request.user,
            )
        else: #이미지 첨부 안됨
            new_post = Post.objects.create(
                title = request.POST['title'],
                content = request.POST['content'],
                author=request.user,
            )
        return redirect('/board')
    return render(request, 'board/new.html')

def show(request, pk):
    post = Post.objects.get(pk=pk)
    return render(request, 'board/show.html', {
        'post': post,
    })

def remove(request, pk):
    post = Post.objects.get(pk=pk)
    post.delete()
    return redirect("/board")