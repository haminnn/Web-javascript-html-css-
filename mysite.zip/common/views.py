from django.shortcuts import render, redirect
from common.forms import UserForm

# Create your views here.
def index(request):
    return render(request, "common/index.html")

#  가입 뷰
def signup(request):
    if request.method == "POST":
        # 실제 가입 로직
        print(request.POST)
        form = UserForm(request.POST)

        if form.is_valid(): # 검증 결과 확인
            form.save()
            return redirect("/") # 홈페이지로 이동
    else: # GET 요청
       form = UserForm() # 가입폼
    return render(request, 'common/signup.html', {"form": form})
